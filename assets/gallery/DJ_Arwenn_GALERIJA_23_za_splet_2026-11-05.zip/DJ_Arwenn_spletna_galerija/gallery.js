(() => {
  'use strict';
  const host = document.querySelector('#utrinki .moments-teaser');
  if (!host || document.getElementById('arwenn-photo-gallery')) return;

  // Stay on the existing teaser until the real photographs have been uploaded.
  const path = 'assets/gallery/';
  const photoInfo = [
    [1, 'nastopi', 'Pod šotorom'],
    [2, 'nastopi', 'Za DJ-pultom'],
    [3, 'nastopi', 'Prvi samostojni nastop'],
    [4, 'portreti', 'Studijski portret'],
    [5, 'nastopi', 'Nastop z dolgimi rokavi'],
    [6, 'nastopi', 'DJ pri delu'],
    [7, 'portreti', 'Temni portret'],
    [8, 'portreti', 'Portret z obeskom'],
    [9, 'portreti', 'Portret s tatuji'],
    [10, 'portreti', 'Nagajiv nasmeh'],
    [11, 'portreti', 'Pogled v kamero'],
    [12, 'portreti', 'Pogled vstran'],
    [13, 'portreti', 'Svetlejši portret'],
    [14, 'portreti', 'Temnejši portret'],
    [15, 'portreti', 'Polovica v senci'],
    [16, 'utrinki', 'Utrinek z odra'],
    [17, 'utrinki', 'Utrinek z odra – druga različica'],
    [18, 'nastopi', 'Za Pioneerjem'],
    [19, 'nastopi', 'Za mešalno mizo'],
    [20, 'portreti', 'Studijski portret s prekrižanimi rokami'],
    [21, 'portreti', 'Originalni studijski portret'],
    [22, 'portreti', 'Originalni studijski nasmeh'],
    [23, 'nastopi', 'Pod šotorom – pogled s strani']
  ];
  const photos = photoInfo.map(([n, cat, title]) => ({
    n, cat, title,
    full: `${path}${String(n).padStart(2, '0')}.webp`,
    thumb: `${path}${String(n).padStart(2, '0')}-thumb.webp`
  }));
  const i18n = {
    sl: {
      heading: 'PRAVI TRENUTKI. PRAVA GLASBA.',
      intro: 'Utrinki z nastopov, portreti in pogledi za DJ-pult. Vsaka slika ima svojo zgodbo.',
      all: 'VSE', nastopi: 'NASTOPI', portreti: 'PORTRETI', utrinki: 'UTRINKI',
      open: 'Odpri fotografijo', close: 'Zapri', prev: 'Prejšnja fotografija', next: 'Naslednja fotografija',
      count: 'fotografij'
    },
    en: {
      heading: 'REAL MOMENTS. REAL MUSIC.',
      intro: 'Live moments, portraits, and a look behind the decks. Every photo tells a story.',
      all: 'ALL', nastopi: 'LIVE', portreti: 'PORTRAITS', utrinki: 'MOMENTS',
      open: 'Open photo', close: 'Close', prev: 'Previous photo', next: 'Next photo',
      count: 'photos'
    }
  };
  const style = document.createElement('style');
  style.textContent = `
    .arwenn-gallery{margin:34px 0 48px;color:#f8f7f8}
    .arwenn-gallery h3{font-size:clamp(23px,3.2vw,40px);font-weight:900;letter-spacing:-.045em;line-height:1.05;margin:0 0 9px;color:#fff}
    .arwenn-gallery p{font-size:clamp(13px,1.25vw,16px);line-height:1.7;color:#bab4b9;margin:0 0 25px;max-width:68ch}
    .arwenn-gallery-head{display:flex;align-items:center;justify-content:space-between;gap:14px;flex-wrap:wrap;margin-bottom:22px}
    .arwenn-gallery-filters{display:flex;gap:9px;flex-wrap:wrap}
    .arwenn-gallery-filters button{font:800 11px/1.2 Inter,Arial,sans-serif;letter-spacing:.08em;padding:11px 16px;min-height:42px;border-radius:6px;cursor:pointer;border:1px solid #ffffff36;background:#1b191e;color:#f4f2f4}
    .arwenn-gallery-filters button[aria-pressed=true]{background:#d81337;border-color:#ed294a;color:#fff}
    .arwenn-gallery-filters button:focus-visible,.arwenn-photo:focus-visible,.arwenn-gallery-dialog button:focus-visible{outline:3px solid #f95c77;outline-offset:3px}
    .arwenn-gallery-count{font:800 11px/1.4 Inter,Arial,sans-serif;letter-spacing:.1em;color:#a9a2a8}
    .arwenn-gallery-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px}
    .arwenn-photo{display:block;position:relative;min-width:0;border:1px solid #ffffff32;border-radius:9px;overflow:hidden;padding:0;cursor:zoom-in;background:#19171b;color:#fff;aspect-ratio:4/5;box-shadow:0 12px 25px #0004}
    .arwenn-photo img{display:block;width:100%;height:100%;object-fit:cover;transition:transform .32s ease,filter .32s ease}
    .arwenn-photo:hover img{transform:scale(1.035);filter:brightness(1.09)}
    .arwenn-photo span{position:absolute;bottom:0;left:0;right:0;display:block;background:linear-gradient(transparent,#000b);padding:32px 11px 11px;text-align:left;font-size:11px;line-height:1.4;font-weight:750;text-shadow:0 2px 5px #000}
    .arwenn-photo[hidden]{display:none!important}
    .arwenn-gallery-dialog{border:1px solid #ffffff38;background:#0e0e11;color:#fff;border-radius:12px;padding:0;width:min(96vw,1200px);max-width:96vw;max-height:96vh;box-shadow:0 35px 100px #000b}
    .arwenn-gallery-dialog::backdrop{background:#000e;backdrop-filter:blur(6px)}
    .arwenn-gallery-lightbox{position:relative;display:grid;grid-template-columns:minmax(48px,1fr) minmax(0,12fr) minmax(48px,1fr);align-items:center;min-height:min(80vh,650px);padding:52px 5px 45px}
    .arwenn-gallery-lightbox img{max-height:75vh;max-width:100%;width:auto;height:auto;margin:auto;object-fit:contain}
    .arwenn-gallery-dialog button{cursor:pointer;border:1px solid #ffffff4a;background:#222228df;color:#fff;border-radius:7px;min-width:42px;min-height:42px;font-size:24px}
    .arwenn-gallery-dialog .arwenn-gallery-close{position:absolute;top:8px;right:10px;z-index:2}
    .arwenn-gallery-caption{position:absolute;left:15px;right:15px;bottom:12px;text-align:center;font:700 12px/1.4 Inter,Arial,sans-serif;color:#ded9de}
    @media(max-width:900px){.arwenn-gallery-grid{grid-template-columns:repeat(3,minmax(0,1fr))}}
    @media(max-width:650px){.arwenn-gallery{margin:28px 0 40px}.arwenn-gallery-grid{grid-template-columns:repeat(2,minmax(0,1fr));gap:9px}.arwenn-gallery-filters button{padding:10px 11px;font-size:10px}.arwenn-photo{border-radius:7px}.arwenn-photo span{font-size:10px;padding:22px 8px 9px}}
    @media(max-width:350px){.arwenn-gallery-grid{gap:6px}.arwenn-gallery-filters{gap:5px}}
    @media(prefers-reduced-motion:reduce){.arwenn-photo img{transition:none}}`;

  const gallery = document.createElement('section');
  gallery.id = 'arwenn-photo-gallery';
  gallery.className = 'arwenn-gallery';
  gallery.setAttribute('aria-label', 'DJ Arwenn – galerija fotografij');
  gallery.innerHTML = `<h3 class="arwenn-gallery-title"></h3><p class="arwenn-gallery-intro"></p>
      <div class="arwenn-gallery-head"><div class="arwenn-gallery-filters" role="group" aria-label="Filter fotografij"></div><span class="arwenn-gallery-count" aria-live="polite"></span></div>
      <div class="arwenn-gallery-grid"></div>`;
  const grid = gallery.querySelector('.arwenn-gallery-grid');
  const filterBox = gallery.querySelector('.arwenn-gallery-filters');
  const count = gallery.querySelector('.arwenn-gallery-count');
  const categories = ['all', 'nastopi', 'portreti', 'utrinki'];
  const buttons = categories.map(category => {
    const button = document.createElement('button');
    button.type = 'button';
    button.dataset.category = category;
    button.setAttribute('aria-pressed', category === 'all' ? 'true' : 'false');
    filterBox.append(button);
    return button;
  });
  photos.forEach(photo => {
    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'arwenn-photo';
    button.dataset.category = photo.cat;
    button.dataset.number = photo.n;
    const image = document.createElement('img');
    image.src = photo.thumb;
    image.alt = `DJ Arwenn – ${photo.title}`;
    image.loading = 'lazy';
    image.decoding = 'async';
    const label = document.createElement('span');
    label.textContent = photo.title;
    button.append(image,label);
    grid.append(button);
  });

  const modal = document.createElement('dialog');
  modal.className = 'arwenn-gallery-dialog';
  modal.innerHTML = `<div class="arwenn-gallery-lightbox">
    <button class="arwenn-gallery-close" type="button" aria-label="Zapri">×</button>
    <button class="arwenn-gallery-prev" type="button" aria-label="Prejšnja fotografija">‹</button>
    <img alt="" />
    <button class="arwenn-gallery-next" type="button" aria-label="Naslednja fotografija">›</button>
    <div class="arwenn-gallery-caption" aria-live="polite"></div>
    </div>`;
  let currentFilter='all';
  let activePhotos=photos;
  let activeIndex=0;
  function lang(){return document.documentElement.lang.toLowerCase().startsWith('en')?'en':'sl';}
  function translate(){
    const t=i18n[lang()];
    gallery.querySelector('.arwenn-gallery-title').textContent=t.heading;
    gallery.querySelector('.arwenn-gallery-intro').textContent=t.intro;
    buttons.forEach(button=>button.textContent=t[button.dataset.category]);
    modal.querySelector('.arwenn-gallery-close').setAttribute('aria-label',t.close);
    modal.querySelector('.arwenn-gallery-prev').setAttribute('aria-label',t.prev);
    modal.querySelector('.arwenn-gallery-next').setAttribute('aria-label',t.next);
    grid.querySelectorAll('.arwenn-photo').forEach(button=>button.setAttribute('aria-label',t.open+': '+photos.find(p=>p.n===Number(button.dataset.number)).title));
    count.textContent=`${activePhotos.length} ${t.count}`;
  }
  function filter(category){
    currentFilter=category;
    activePhotos=photos.filter(p=>category==='all'||p.cat===category);
    grid.querySelectorAll('.arwenn-photo').forEach(button=>button.hidden=category!=='all'&&button.dataset.category!==category);
    buttons.forEach(button=>button.setAttribute('aria-pressed',String(button.dataset.category===category)));
    translate();
  }
  function showPhoto(index){
    activeIndex=(index+activePhotos.length)%activePhotos.length;
    const photo=activePhotos[activeIndex];
    const image=modal.querySelector('img');
    image.src=photo.full;
    image.alt=`DJ Arwenn – ${photo.title}`;
    modal.querySelector('.arwenn-gallery-caption').textContent=`${activeIndex+1} / ${activePhotos.length} · ${photo.title}`;
  }
  buttons.forEach(button=>button.addEventListener('click',()=>filter(button.dataset.category)));
  grid.addEventListener('click',event=>{
    const button=event.target.closest('button.arwenn-photo');
    if(!button)return;
    const index=activePhotos.findIndex(p=>p.n===Number(button.dataset.number));
    if(index<0)return;
    showPhoto(index);
    modal.showModal();
  });
  modal.querySelector('.arwenn-gallery-close').addEventListener('click',()=>modal.close());
  modal.querySelector('.arwenn-gallery-prev').addEventListener('click',()=>showPhoto(activeIndex-1));
  modal.querySelector('.arwenn-gallery-next').addEventListener('click',()=>showPhoto(activeIndex+1));
  modal.addEventListener('click',event=>{if(event.target===modal)modal.close();});
  modal.addEventListener('keydown',event=>{
    if(event.key==='ArrowLeft'){event.preventDefault();showPhoto(activeIndex-1);}
    if(event.key==='ArrowRight'){event.preventDefault();showPhoto(activeIndex+1);}
  });

  const firstImage=new Image();
  firstImage.onload=()=>{
    document.head.append(style);
    host.replaceWith(gallery);
    document.body.append(modal);
    filter('all');
    new MutationObserver(translate).observe(document.documentElement,{attributes:true,attributeFilter:['lang']});
  };
  firstImage.onerror=()=>{ /* Preserve the existing teaser until assets are uploaded. */ };
  firstImage.src=photos[0].thumb;
})();
