DJ ARWENN - GALERIJA ZA SPLETNO STRAN, 23 IZBRANIH FOTOGRAFIJ

Vkljucuje:
- gallery.js: dostopna responsivna galerija, filtri Nastopi / Portreti / Utrinki,
  prikaz celozaslonske fotografije, tipkovnica, slovenscina in anglescina
- assets/gallery/01.webp do 23.webp: optimizirane velike fotografije
- assets/gallery/01-thumb.webp do 23-thumb.webp: majhne fotografije za mrezo
- fotografije.csv: seznam vsebine in kategorij

NAMESITEV V GITHUB REPO sasolju999-ui/dj-arwenn-website:
1. Nalozi celotno mapo assets/gallery/ na isto pot v repozitoriju.
2. Nalozi gallery.js v koren repozitorija.
3. Tik pred zakljucnim </body> v index.html dodaj vrstico:
   <script defer src="gallery.js"></script>
4. Po objavi odpri https://djarwenn.pages.dev/#utrinki in preveri ogled fotografij.

NASVET: gallery.js se aktivira le, ce se prva mala fotografija uspesno nalozi.
Ce slike se niso nalozene, obdrzi obstojece vabilo "Utrinki kmalu".
Koda ne spreminja obrazca, API-ja, gesel, koledarja ali datumov rezervacij.

ARHIV: To so optimizirane kopije. Originalne fotografije ostajajo v locenem ZIP.
